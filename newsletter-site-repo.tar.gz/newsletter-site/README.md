# 學海無涯 Newsletter Archive

靜態 HTML newsletter 站點，由 Claude 自動生成，Cloudflare Pages 自動部署。

## 結構

```
newsletters/
├── index.html              ← 文章目錄頁（由 build.py 自動生成）
├── 3690-meituan-q4-2025/
│   └── index.html          ← 單篇 newsletter
├── assets/
│   └── index-style.css     ← 目錄頁樣式
```

## 發佈流程

1. Claude 生成 newsletter HTML
2. 放入 `newsletters/{slug}/index.html`
3. 執行 `python scripts/build.py` 重新生成目錄頁
4. Git push → Cloudflare Pages 自動部署（~30秒）

## Cloudflare Pages 設置

- Build command: `python scripts/build.py`
- Build output directory: `newsletters`
- 自訂域名: 按需設定
