#!/usr/bin/env python3
"""
Auto-generate index.html for newsletter archive.
Scans newsletters/ for subdirectories containing index.html,
extracts <title> tag content, and builds a styled directory page.
"""

import os
import re
from pathlib import Path
from datetime import datetime

NEWSLETTERS_DIR = Path(__file__).parent.parent / "newsletters"
INDEX_STYLE = (NEWSLETTERS_DIR / "assets" / "index-style.css").read_text() if (NEWSLETTERS_DIR / "assets" / "index-style.css").exists() else ""

def extract_title(html_path):
    """Extract content from <title> tag."""
    content = html_path.read_text(encoding="utf-8")
    match = re.search(r"<title>(.*?)</title>", content, re.IGNORECASE)
    if match:
        title = match.group(1)
        # Remove "學海無涯 | " prefix if present
        title = re.sub(r"^學海無涯\s*\|\s*", "", title)
        return title
    return html_path.parent.name

def extract_date_from_html(html_path):
    """Try to extract date from masthead-date div."""
    content = html_path.read_text(encoding="utf-8")
    match = re.search(r'class="masthead-date"[^>]*>(.*?)</div>', content, re.IGNORECASE)
    if match:
        return match.group(1).strip()
    return ""

def extract_type_from_html(html_path):
    """Try to extract newsletter type from masthead-date or hero-tag."""
    content = html_path.read_text(encoding="utf-8")
    # Check for type keywords
    for keyword in ["個股深度", "Stock Deep-Dive", "Article Digest", "Macro Research", "Quick Take", "文章摘要", "宏觀研究"]:
        if keyword in content:
            return keyword
    return ""

def get_newsletters():
    """Scan for all newsletter directories."""
    entries = []
    for d in sorted(NEWSLETTERS_DIR.iterdir(), reverse=True):
        if d.is_dir() and d.name not in ("assets", ".git", "__pycache__"):
            index = d / "index.html"
            if index.exists():
                title = extract_title(index)
                date_str = extract_date_from_html(index)
                ntype = extract_type_from_html(index)
                mtime = datetime.fromtimestamp(index.stat().st_mtime)
                entries.append({
                    "slug": d.name,
                    "title": title,
                    "date": date_str,
                    "type": ntype,
                    "mtime": mtime.strftime("%Y-%m-%d"),
                })
    return entries

def build_index(entries):
    """Generate index.html."""
    rows = ""
    for e in entries:
        type_badge = f'<span class="type-badge">{e["type"]}</span>' if e["type"] else ""
        rows += f"""
    <a href="{e['slug']}/" class="entry">
      <div class="entry-title">{e['title']}</div>
      <div class="entry-meta">
        {type_badge}
        <span class="entry-date">{e['date'] or e['mtime']}</span>
      </div>
    </a>"""

    count = len(entries)

    html = f"""<!DOCTYPE html>
<html lang="zh-Hant">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>學海無涯 Newsletter Archive</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400&family=Noto+Serif+TC:wght@400;700;900&family=Source+Sans+Pro:wght@300;400;600;700&display=swap" rel="stylesheet">
<style>
:root {{
  --bg-primary:#0a0a08;
  --bg-card:#111110;
  --gold:#c9a84c;
  --gold-bright:#f0d87a;
  --gold-dark:#8a6f2f;
  --white:#ffffff;
  --cream:#f0ebe0;
  --muted:#c4b896;
  --border-gold:rgba(201,168,76,0.3);
  --border-faint:rgba(201,168,76,0.12);
}}
*{{margin:0;padding:0;box-sizing:border-box;}}
html,body{{background:var(--bg-primary)!important;color:var(--cream);font-family:'Noto Serif TC','Source Sans Pro',serif;min-height:100vh;}}

.header{{border-bottom:3px double var(--gold);padding:2.5rem 1.5rem 1.5rem;text-align:center;}}
.header-brand{{font-family:'Playfair Display',serif;font-size:0.72rem;letter-spacing:6px;text-transform:uppercase;color:var(--gold);}}
.header-title{{font-family:'Noto Serif TC',serif;font-size:1.4rem;color:var(--white);letter-spacing:3px;margin-top:0.3rem;}}
.header-sub{{font-family:'Source Sans Pro',sans-serif;font-size:0.7rem;color:var(--muted);margin-top:0.5rem;letter-spacing:1px;}}

.container{{max-width:800px;margin:0 auto;padding:2rem 1.2rem;}}

.entry{{display:block;background:var(--bg-card);border:1px solid var(--border-faint);border-left:3px solid var(--gold-dark);padding:1.2rem 1.5rem;margin-bottom:0.8rem;text-decoration:none;transition:border-color 0.2s, background 0.2s;}}
.entry:hover{{border-left-color:var(--gold);background:#161510;}}
.entry-title{{font-family:'Noto Serif TC',serif;font-size:1.05rem;font-weight:700;color:var(--white);margin-bottom:0.4rem;}}
.entry-meta{{display:flex;align-items:center;gap:0.8rem;flex-wrap:wrap;}}
.entry-date{{font-family:'Source Sans Pro',sans-serif;font-size:0.68rem;color:var(--muted);}}
.type-badge{{font-family:'Source Sans Pro',sans-serif;font-size:0.58rem;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:var(--gold);background:rgba(201,168,76,0.1);padding:0.15rem 0.5rem;border-radius:2px;}}

.footer{{border-top:1px solid var(--border-gold);padding:2rem 0;margin-top:2rem;text-align:center;}}
.footer-brand{{font-family:'Noto Serif TC',serif;font-size:0.78rem;color:var(--gold);letter-spacing:2px;}}
.footer-links{{margin-top:0.8rem;display:flex;justify-content:center;gap:1.5rem;}}
.footer-links a{{font-family:'Source Sans Pro',sans-serif;font-size:0.62rem;color:var(--gold-dark);text-decoration:none;letter-spacing:1px;text-transform:uppercase;}}
.footer-links a:hover{{color:var(--gold);}}
</style>
</head>
<body>

<div class="header">
  <div class="header-brand">學海無涯 Newsletter Archive</div>
  <div class="header-title">學海無涯戰友訓練班</div>
  <div class="header-sub">{count} issues published</div>
</div>

<div class="container">
{rows}
</div>

<div class="footer">
  <div class="footer-brand">學海無涯戰友訓練班</div>
  <div class="footer-links">
    <a href="https://www.patreon.com/" target="_blank">Patreon</a>
    <a href="https://t.me/AIreturn" target="_blank">Telegram</a>
    <a href="https://www.threads.net/@aireturn88" target="_blank">Threads</a>
  </div>
</div>

</body>
</html>"""
    return html

def main():
    entries = get_newsletters()
    index_html = build_index(entries)
    output = NEWSLETTERS_DIR / "index.html"
    output.write_text(index_html, encoding="utf-8")
    print(f"✅ Built index.html with {len(entries)} entries")

if __name__ == "__main__":
    main()
